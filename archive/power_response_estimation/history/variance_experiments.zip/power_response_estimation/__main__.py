import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
from .cli import main

raise SystemExit(main())
