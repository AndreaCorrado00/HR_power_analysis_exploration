# Archivio G1/G2

CSV originali invariati, suddivisi secondo le classificazioni già prodotte.
UtD_G1, DtU_G1, Ambigui_G1; UtD_G2, DtU_G2, Ambigui_G2.
DtU_G2 è presente anche se vuota. G3/G4 sono esclusi provvisoriamente,
non eliminati dalla fonte: durata e presenza nel dataset considerate ambigue.
"Certi" significa non ambigui secondo le regole empiriche attuali,
non validati indipendentemente. Nessun nuovo fitting o preprocessing.

Il manifest conserva i metadati originari e aggiorna i percorsi dei CSV.
metadata/selection.json registra assegnazioni, esclusioni e hash.
metadata/grouping_criteria.md conserva i criteri del report originale;
i link alle immagini in quel documento si riferiscono al report nel repository.

Riproduzione dalla radice del repository:
`.venv/Scripts/python scripts/package_segment_groups.py --output dataset/nuovo_archivio.zip`
L'output deve essere un file nuovo: lo script non sovrascrive archivi esistenti.
