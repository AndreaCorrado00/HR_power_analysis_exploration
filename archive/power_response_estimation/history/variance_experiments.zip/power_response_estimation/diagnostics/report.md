# Diagnostica della varianza delle innovazioni AR(2)

Analisi descrittiva di validation e test già esaminati; nessun fitting del modello o GARCH. Innovazioni finite: 143005. Coefficienti, predizioni e risultati precedenti invariati (SHA256 in manifest.json).

Approfondimento successivo: [intervalli, plateau e controllo con rimescolamenti](interval_report.md).

## Conclusione

**Esiste evidenza sufficiente per valutare un AR-GARCH come prossimo confronto, ma non per sostituire già l’AR attuale.** I quadrati delle innovazioni mostrano clustering a breve termine: l’ACF è positiva soprattutto nei primi 10–20 secondi e si attenua ai lag maggiori. Tutti i 24 workout rifiutano l’assenza di effetti ARCH a tutti e tre i lag, anche dopo FDR (massimo p corretto delle innovazioni originali: 7.06e-10). La numerosità rende rilevabili effetti relativamente contenuti: il R² ausiliario mediano a 30 lag è circa 7%, non una misura di guadagno predittivo della potenza.

- **validation**: ACF ε² a 1 s = 0.166; dopo scala target = 0.163. R² mediano ARCH(30): 6.7%, scala target 5.8%, scala lap 5.1%. Varianza entro workout: target 150–199 W 1994 W², 400–449 W 7432 W². Transizioni/plateau: rapporto 2.55.
- **test**: ACF ε² a 1 s = 0.157; dopo scala target = 0.141. R² mediano ARCH(30): 7.0%, scala target 6.2%, scala lap 6.0%. Varianza entro workout: target 150–199 W 1437 W², 400–449 W 8078 W². Transizioni/plateau: rapporto 3.03.

Il contesto conta chiaramente: target elevati e transizioni hanno errori più variabili; anche lap e fasi differiscono. Tuttavia la normalizzazione per target o lap non elimina la dipendenza a breve termine né i rigetti ARCH (24/24 workout a ciascun lag anche nelle due sensibilità). **Il risultato è misto: contesto e memoria dei quadrati, non evidenza che il solo contesto sia sufficiente.** Non è possibile attribuire causalmente la quota di varianza all’uno o all’altra usando questi confronti.

Un eventuale esperimento successivo dovrebbe confrontare fuori campione varianza costante, varianza condizionata al contesto e AR-GARCH, valutando calibrazione/copertura e score probabilistici. GARCH non è stato fittato. La sola significatività ARCH non dimostra persistenza GARCH di lungo periodo, né maggiore accuratezza della media; l’ACF accessoria delle innovazioni va mantenuta nella verifica della specificazione della media. Le scale per contesto qui utilizzate non sono modelli predittivi.

## Metodo e interpretazione

- ε_t = e_t − c − φ₁e_(t−1) − φ₂e_(t−2), e = reale − target − risposta dinamica. Verificata numericamente la coerenza del CSV con i coefficienti congelati. Unità W; varianze W².
- Solo tratti contigui a 1 Hz, con innovazioni finite. Nessuna interpolazione, clipping o attraversamento dei gap. Non si interrompono i tratti ai cambi di target/lap.
- ACF dei quadrati fino a 120 s: centratura separata per tratto, somma dei prodotti a lag / somma delle energie dei tratti con lunghezza maggiore del lag (stimatore biased). Esportati numero di coppie, aggregato pesato per energia e mediana dei workout. La centratura rimuove differenze di livello fra tratti, non cambi di varianza interni.
- ARCH-LM: regressione ausiliaria ε² su intercetta e q lag di ε²; LM=N·R², p-value χ²(q), q=5/15/30 s. ddof=0 perché il modello della media è stato stimato sul training separato. Righe unite solo dopo aver formato i lag entro tratto. Sono esportati anche F e relativo p-value. Serie degeneri/rango insufficiente sono marcate, non considerate negative.
- Aggregazione ARCH: somma delle LM dei workout, riferimento χ²(12q); non richiede coefficienti ARCH uguali. Assume indipendenza fra workout: stessi atleta e periodo possono limitarla. Nessun test ottenuto concatenando serie. BH-FDR sui 72 confronti workout×lag separatamente per modalità; sui 6 confronti aggregati separatamente per modalità. I p-value nulli in CSV indicano underflow numerico, non probabilità matematicamente nulla.
- Contesto: fasce [b,b+50) W, lap e phase_index originali, più inizio tratto/primi 30 s dopo cambio target/plateau. Le prime due categorie hanno priorità in questo ordine. Conteggi, media, varianza campionaria e media dei quadrati sono esportati. Negli aggregati sono disponibili sia varianza totale sia varianza pooled entro workout/cella.
- Sensibilità: ε diviso per deviazione standard entro workout×fascia target, oppure workout×lap. Nessuna sottrazione della media; celle <60 campioni o con varianza nulla usano la deviazione standard del workout. Fallback: {'target_scaled': 484, 'lap_scaled': 10625}. Le scale sono stimate sugli stessi dati: ACF e test normalizzati sono esplorativi, non test confermativi né validazione di un modello di varianza.
- Varianza mobile: finestra trailing di 60 campioni interamente validi nello stesso tratto, ddof=1. La sovrapposizione delle finestre produce di per sé smoothness: i grafici supportano la lettura, non sono un test di clustering.
- ARCH significativo non identifica un GARCH: cambi di regime, outlier, target, transizioni e misspecificazione della media possono produrre dipendenza dei quadrati. È esportata anche ACF di ε (mode=epsilon) per verificare la media.

Definizione ARCH-LM e ddof: [documentazione statsmodels](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.het_arch.html) e [regressione LM](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.acorr_lm.html). Implementazione NumPy/SciPy senza nuova dipendenza.

## Risultati aggregati originali

| split | lag_s | nobs | lm_sum | df | p_value | significant_fdr | median_r_squared |
|---|---|---|---|---|---|---|---|
| test | 5 | 51268 | 2563 | 60 | <1e-300 | 12 | 0.04423 |
| test | 15 | 50683 | 3355 | 180 | <1e-300 | 12 | 0.06363 |
| test | 30 | 49851 | 3450 | 360 | <1e-300 | 12 | 0.07045 |
| validation | 5 | 91065 | 3924 | 60 | <1e-300 | 12 | 0.04351 |
| validation | 15 | 90325 | 4951 | 180 | <1e-300 | 12 | 0.06124 |
| validation | 30 | 89237 | 5512 | 360 | <1e-300 | 12 | 0.06734 |

## Sensibilità alla scala del contesto

| split | mode | lag_s | significant_fdr | median_r_squared |
|---|---|---|---|---|
| test | lap_scaled | 5 | 12 | 0.04436 |
| test | lap_scaled | 15 | 12 | 0.05479 |
| test | lap_scaled | 30 | 12 | 0.05972 |
| test | raw | 5 | 12 | 0.04423 |
| test | raw | 15 | 12 | 0.06363 |
| test | raw | 30 | 12 | 0.07045 |
| test | target_scaled | 5 | 12 | 0.0376 |
| test | target_scaled | 15 | 12 | 0.05481 |
| test | target_scaled | 30 | 12 | 0.06155 |
| validation | lap_scaled | 5 | 12 | 0.04099 |
| validation | lap_scaled | 15 | 12 | 0.04824 |
| validation | lap_scaled | 30 | 12 | 0.05116 |
| validation | raw | 5 | 12 | 0.04351 |
| validation | raw | 15 | 12 | 0.06124 |
| validation | raw | 30 | 12 | 0.06734 |
| validation | target_scaled | 5 | 12 | 0.04303 |
| validation | target_scaled | 15 | 12 | 0.05416 |
| validation | target_scaled | 30 | 12 | 0.05842 |

## Risultati per workout (innovazioni originali)

| split | workout_id | lag_s | nobs | lm | p_value | p_fdr | r_squared |
|---|---|---|---|---|---|---|---|
| test | 260819062707 | 5 | 5282 | 237.7 | 2.376e-49 | 3.719e-49 | 0.045 |
| test | 260819062707 | 15 | 5262 | 295.2 | 5.543e-54 | 9.734e-54 | 0.0561 |
| test | 260819062707 | 30 | 5232 | 295.2 | 2.326e-45 | 3.418e-45 | 0.05642 |
| test | 260826062619 | 5 | 5017 | 299.4 | 1.35e-62 | 3.134e-62 | 0.05968 |
| test | 260826062619 | 15 | 4977 | 334.2 | 4.306e-62 | 9.689e-62 | 0.06714 |
| test | 260826062619 | 30 | 4917 | 362.5 | 9.792e-59 | 1.958e-58 | 0.07373 |
| test | 260827070608 | 5 | 4427 | 106.3 | 2.475e-21 | 2.7e-21 | 0.02401 |
| test | 260827070608 | 15 | 4361 | 300.3 | 4.945e-55 | 8.902e-55 | 0.06885 |
| test | 260827070608 | 30 | 4271 | 312.7 | 8.061e-49 | 1.235e-48 | 0.07323 |
| test | 260829063044 | 5 | 4492 | 307.3 | 2.757e-64 | 6.844e-64 | 0.0684 |
| test | 260829063044 | 15 | 4472 | 363 | 3.953e-68 | 1.294e-67 | 0.08118 |
| test | 260829063044 | 30 | 4442 | 416.8 | 1.128e-69 | 4.062e-69 | 0.09383 |
| test | 260830095410 | 5 | 2114 | 51.43 | 7.062e-10 | 7.062e-10 | 0.02433 |
| test | 260830095410 | 15 | 2075 | 96.07 | 7.222e-14 | 7.428e-14 | 0.0463 |
| test | 260830095410 | 30 | 2030 | 103.1 | 5.87e-10 | 5.953e-10 | 0.05081 |
| test | 260901062237 | 5 | 4764 | 251.9 | 2.155e-52 | 3.694e-52 | 0.05287 |
| test | 260901062237 | 15 | 4734 | 312.1 | 1.662e-57 | 3.149e-57 | 0.06594 |
| test | 260901062237 | 30 | 4689 | 323.2 | 6.809e-51 | 1.14e-50 | 0.06893 |
| test | 260902062649 | 5 | 4818 | 152.2 | 4.453e-31 | 5.172e-31 | 0.0316 |
| test | 260902062649 | 15 | 4718 | 180.8 | 1.614e-30 | 1.844e-30 | 0.03833 |
| test | 260902062649 | 30 | 4568 | 171.1 | 1.07e-21 | 1.186e-21 | 0.03746 |
| test | 260904062108 | 5 | 4511 | 131.4 | 1.219e-26 | 1.372e-26 | 0.02912 |
| test | 260904062108 | 15 | 4451 | 272.9 | 2.305e-49 | 3.688e-49 | 0.06132 |
| test | 260904062108 | 30 | 4361 | 289.4 | 3.234e-44 | 4.656e-44 | 0.06636 |
| test | 260905142842 | 5 | 2169 | 90.48 | 5.331e-18 | 5.729e-18 | 0.04171 |
| test | 260905142842 | 15 | 2069 | 110.8 | 1.145e-16 | 1.212e-16 | 0.05354 |
| test | 260905142842 | 30 | 1942 | 139.8 | 4.241e-16 | 4.425e-16 | 0.07197 |
| test | 260908061657 | 5 | 4702 | 346.6 | 9.51e-73 | 4.891e-72 | 0.07371 |
| test | 260908061657 | 15 | 4662 | 373.1 | 3.085e-70 | 1.307e-69 | 0.08003 |
| test | 260908061657 | 30 | 4602 | 357.7 | 9.115e-58 | 1.774e-57 | 0.07772 |
| test | 260915062325 | 5 | 4503 | 195.7 | 2.355e-40 | 3.028e-40 | 0.04346 |
| test | 260915062325 | 15 | 4483 | 211.3 | 1.076e-36 | 1.313e-36 | 0.04713 |
| test | 260915062325 | 30 | 4453 | 260.2 | 1.627e-38 | 2.02e-38 | 0.05843 |
| test | 260919065417 | 5 | 4469 | 392.7 | 1.092e-82 | 6.552e-82 | 0.08788 |
| test | 260919065417 | 15 | 4419 | 505.7 | 3.435e-98 | 2.748e-97 | 0.1144 |
| test | 260919065417 | 30 | 4344 | 417.9 | 6.762e-70 | 2.609e-69 | 0.0962 |
| validation | 260606075342 | 5 | 14347 | 666.7 | 7.733e-142 | 1.856e-140 | 0.04647 |
| validation | 260606075342 | 15 | 14277 | 837.4 | 8.877e-169 | 6.391e-167 | 0.05865 |
| validation | 260606075342 | 30 | 14172 | 876.2 | 6.064e-165 | 2.183e-163 | 0.06183 |
| validation | 260609170059 | 5 | 5076 | 209.8 | 2.269e-43 | 3.082e-43 | 0.04133 |
| validation | 260609170059 | 15 | 5046 | 246.9 | 5.275e-44 | 7.448e-44 | 0.04894 |
| validation | 260609170059 | 30 | 5001 | 317.9 | 7.727e-50 | 1.264e-49 | 0.06357 |
| validation | 260616171138 | 5 | 5527 | 309.3 | 1.004e-64 | 2.781e-64 | 0.05596 |
| validation | 260616171138 | 15 | 5477 | 371.4 | 6.885e-70 | 2.609e-69 | 0.06781 |
| validation | 260616171138 | 30 | 5410 | 392.2 | 1.054e-64 | 2.812e-64 | 0.07249 |
| validation | 260621150426 | 5 | 9331 | 207.4 | 7.371e-43 | 9.828e-43 | 0.02223 |
| validation | 260621150426 | 15 | 9261 | 303.8 | 9.062e-56 | 1.673e-55 | 0.0328 |
| validation | 260621150426 | 30 | 9156 | 307.6 | 8.328e-48 | 1.249e-47 | 0.0336 |
| validation | 260623171613 | 5 | 6444 | 291.2 | 7.813e-61 | 1.654e-60 | 0.04519 |
| validation | 260623171613 | 15 | 6344 | 369.9 | 1.453e-69 | 4.981e-69 | 0.0583 |
| validation | 260623171613 | 30 | 6194 | 376.1 | 1.808e-61 | 3.946e-61 | 0.06073 |
| validation | 260624171412 | 5 | 4452 | 156.1 | 6.684e-32 | 7.889e-32 | 0.03506 |
| validation | 260624171412 | 15 | 4402 | 196.9 | 8.97e-34 | 1.076e-33 | 0.04473 |
| validation | 260624171412 | 30 | 4327 | 268.1 | 4.758e-40 | 6.011e-40 | 0.06195 |
| validation | 260708172128 | 5 | 5627 | 289.7 | 1.617e-60 | 3.327e-60 | 0.05149 |
| validation | 260708172128 | 15 | 5577 | 356 | 1.185e-66 | 3.556e-66 | 0.06383 |
| validation | 260708172128 | 30 | 5502 | 391.2 | 1.652e-64 | 4.247e-64 | 0.07111 |
| validation | 260714172507 | 5 | 5136 | 211.1 | 1.205e-43 | 1.668e-43 | 0.0411 |
| validation | 260714172507 | 15 | 5076 | 353.8 | 3.386e-66 | 9.752e-66 | 0.0697 |
| validation | 260714172507 | 30 | 4986 | 386 | 1.861e-63 | 4.466e-63 | 0.07742 |
| validation | 260716153012 | 5 | 4769 | 199.5 | 3.568e-41 | 4.67e-41 | 0.04184 |
| validation | 260716153012 | 15 | 4739 | 377.9 | 2.98e-71 | 1.431e-70 | 0.07975 |
| validation | 260716153012 | 30 | 4694 | 504.8 | 1.259e-87 | 8.237e-87 | 0.1075 |
| validation | 260721071628 | 5 | 5946 | 573.5 | 1.096e-121 | 1.972e-120 | 0.09644 |
| validation | 260721071628 | 15 | 5916 | 611.7 | 1.151e-120 | 1.657e-119 | 0.1034 |
| validation | 260721071628 | 30 | 5871 | 635.8 | 1.141e-114 | 1.369e-113 | 0.1083 |
| validation | 260801060832 | 5 | 19205 | 454.5 | 5.273e-96 | 3.796e-95 | 0.02367 |
| validation | 260801060832 | 15 | 19035 | 564.2 | 1.424e-110 | 1.282e-109 | 0.02964 |
| validation | 260801060832 | 30 | 18794 | 634 | 2.667e-114 | 2.743e-113 | 0.03373 |
| validation | 260811165713 | 5 | 5205 | 355.2 | 1.361e-74 | 7.537e-74 | 0.06823 |
| validation | 260811165713 | 15 | 5175 | 361.2 | 9.414e-68 | 2.947e-67 | 0.0698 |
| validation | 260811165713 | 30 | 5130 | 421.8 | 1.068e-70 | 4.804e-70 | 0.08223 |

## Varianza per fascia di target

| split | target_band_w | n | workouts | within_workout_variance_w2 |
|---|---|---|---|---|
| test | 50 | 426 | 5 | 1872 |
| test | 100 | 4246 | 8 | 1588 |
| test | 150 | 33931 | 11 | 1437 |
| test | 200 | 8491 | 8 | 2081 |
| test | 300 | 950 | 7 | 4159 |
| test | 350 | 2695 | 6 | 5719 |
| test | 400 | 647 | 6 | 8078 |
| test | 450 | 177 | 5 | 1.317e+04 |
| validation | 0 | 32 | 2 | 2366 |
| validation | 50 | 548 | 5 | 2631 |
| validation | 100 | 9159 | 10 | 1632 |
| validation | 150 | 37508 | 11 | 1994 |
| validation | 200 | 33932 | 10 | 1850 |
| validation | 250 | 1371 | 3 | 3712 |
| validation | 300 | 4281 | 7 | 3033 |
| validation | 350 | 2987 | 8 | 5528 |
| validation | 400 | 1436 | 5 | 7432 |
| validation | 450 | 188 | 4 | 1.089e+04 |

## Varianza per transizione

| split | transition | n | within_workout_variance_w2 |
|---|---|---|---|
| test | plateau | 43855 | 1496 |
| test | segment_start | 1604 | 4476 |
| test | target_transition | 6104 | 4540 |
| validation | plateau | 81056 | 1887 |
| validation | segment_start | 2061 | 3946 |
| validation | target_transition | 8325 | 4813 |

## Differenze entro workout per contesto

Mediana fra workout del rapporto fra massima e minima varianza di cella; solo celle con almeno 60 campioni e workout con almeno due celle. Descrittivo, sensibile al numero di celle e non corretto per altri contesti. Identificativi lap/fase non sono confrontati direttamente tra workout. Per phase_index il confronto entro workout è disponibile solo in 3 sessioni: non permette una conclusione generale sulle fasi.

| split | context | workouts | median_max_min_ratio |
|---|---|---|---|
| test | target | 11 | 4.415 |
| validation | target | 12 | 3.899 |
| test | lap | 12 | 6.971 |
| validation | lap | 12 | 4.879 |
| test | phase | 2 | 3.359 |
| validation | phase | 1 | 3.827 |

## Artefatti e riproduzione

`python -B -m power_response_estimation.diagnostics_analysis` dalla radice. Richiede le dipendenze già presenti: NumPy, pandas, SciPy, Matplotlib. Rigenera solo diagnostics/. Configurazione e hash in manifest.json; nessuna casualità.

- acf_squared.csv: ACF per workout (mode=epsilon è la diagnostica accessoria non elevata al quadrato).
- acf_aggregate.csv, arch_lm_workouts.csv, arch_lm_aggregate.csv: statistiche e numerosità.
- variance_*.csv: tabelle per target, fase, lap, transizioni e workout; rolling_variance.csv: serie mobile.
- acf_summary.png, acf_workouts.png, variance_target.png, variance_<split>_<workout>.png: grafici.

![ACF aggregate](acf_summary.png)

![Varianza per target](variance_target.png)
