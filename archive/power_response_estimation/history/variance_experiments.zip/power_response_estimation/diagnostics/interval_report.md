# Intervalli, plateau e rialzo ACF a 40–60 secondi

Approfondimento descrittivo dei 24 workout già esaminati. Modello congelato, nessun GARCH. La finestra 40–60 s è stata scelta dopo aver visto il grafico precedente: risultati esplorativi.

## Interpretazione

**La dipendenza a breve termine sopravvive al controllo per intervalli e transizioni; il rialzo attorno a 50 s non è altrettanto robusto.** Il contesto genera da solo una parte dell’ACF originale: la mediana del riferimento rimescolato raw è positiva. Tuttavia non riproduce la forte associazione dei primi secondi, presente anche nei plateau.

- **validation**: ACF a 1 s originale 0.166; entro intervalli 0.138; plateau60 0.136. Media ACF 1–10 s superiore al riferimento nei plateau60 in 12/12 workout dopo FDR. Massimo ACF 40–60 s originale: lag 45 s, p=0.016; nei plateau60: lag 45 s, p=0.024, p FDR=0.048.
- **test**: ACF a 1 s originale 0.157; entro intervalli 0.127; plateau60 0.137. Media ACF 1–10 s superiore al riferimento nei plateau60 in 12/12 workout dopo FDR. Massimo ACF 40–60 s originale: lag 48 s, p=0.062; nei plateau60: lag 55 s, p=0.070, p FDR=0.070.

Nei singoli workout, nessun massimo 40–60 s supera il riferimento dopo FDR nei plateau30 o plateau60. Esistono due casi isolati in altre modalità: test 260915062325 (raw, massimo a 48 s) e validation 260721071628 (within_scaled, massimo a 56 s), entrambi p FDR=0.048. Questa assenza di evidenza diffusa non dimostra assenza di dipendenza: gli aggregati hanno maggiore potenza statistica. In validation resta un eccesso aggregato piccolo; nel test la decisione varia con il taglio 30/60 s (p=0.044/0.070). Con 499 repliche i valori vicini a 0.05 sono anche sensibili all’errore Monte Carlo: non vanno trattati come una distinzione netta.

Al lag esatto 50 s, l’ACF diventa prossima a zero o lievemente negativa entro intervallo in entrambi gli split. Il massimo residuo nella finestra si sposta: non emerge una periodicità stabile di 50 s. Solo una minoranza degli intervalli ha durata o distanza di ripetizione fra 40 e 60 s (tabella sotto). I risultati sono compatibili con un contributo importante della struttura degli intervalli al rialzo originale, ma non attribuiscono ogni picco a una specifica durata.

**Conseguenza modellistica:** resta motivato confrontare una varianza dinamica con una dipendente dal contesto, grazie al segnale breve entro plateau; il presunto picco a 50 s non giustifica un periodo o una dinamica aggiuntiva nel modello. Il rigetto del riferimento entro cella può ancora riflettere variazioni di contesto non osservate, non necessariamente un meccanismo GARCH. Nessun modello è stato modificato o ristimato.

## Protocollo riproducibile

- Intervallo = stesso lap, stesso target esatto e continuità a 1 Hz nello stesso segmento. Le innovazioni mancanti interrompono sempre i prodotti e i lag. Non sono aggiunti dati o interpolazioni.
- raw: supporto e centratura della prima diagnostica; within: solo coppie nello stesso intervallo, con centratura dei quadrati per intervallo continuo. Cambiano quindi sia le coppie sia il livello rimosso. within_scaled: prima si divide ε per la deviazione standard del suo intervallo (almeno 60 valori; altrimenti scala del workout), poi si usa la stessa ACF within. Nessun refit della media.
- La normalizzazione costante per intervallo cambia il peso relativo degli intervalli nell’ACF aggregata; non cambia l’ACF di un singolo intervallo. Non costituisce un modello predittivo della varianza.
- plateau30/plateau60: come within, escludendo campioni con età del target <30/<60 s. L’età riparte da zero ai cambi di target, inizio segmento o gap; non ai soli cambi lap. Soglie diagnostiche, non tempi di assestamento fisiologici. Le scale within_scaled sono stimate sugli stessi dati.
- ACF: stesso stimatore biased precedente, FFT con zero padding per calcolare i prodotti esatti. Ogni lag include soltanto parti più lunghe del lag. Le ACF entro intervallo sono centrate entro intervallo e possono avere una lieve distorsione negativa nelle parti corte; il riferimento rimescolato usa lo stesso stimatore.
- 499 rimescolamenti con seed 20261016: valori scambiati solo entro intervallo × fase (età target sotto/sopra 30 s; 60 s per plateau60), separatamente entro tratti finiti contigui. Restano identici valori, numerosità e posizione temporale delle celle; viene distrutto il loro ordine interno. Le scale di intervallo sono invarianti ai rimescolamenti. Seed separati per workout tramite SHA256.
- Bande al 95% puntuali del riferimento nullo, non intervalli di confidenza né bande simultanee. Ipotesi di scambiabilità entro cella: una variazione di varianza non descritta dal contesto può ancora causare un rigetto. Il rimescolamento distrugge anche la dipendenza breve: il confronto 40–60 s non verifica una memoria aggiuntiva oltre quella già osservata nei primi secondi.
- Due statistiche sintetiche: media ACF nei lag 1–10 s e massimo ACF nei lag 40–60 s. Il secondo confronto tiene conto della ricerca del massimo nei 21 lag, non della scelta post-hoc della finestra. p Monte Carlo unilaterale = (1 + repliche almeno altrettanto estreme)/(499+1), minimo 0.002. BH-FDR sui 24 workout separatamente per modalità/finestra; aggregati separatamente sui 2 split. La significatività riguarda eccessi rispetto al contesto definito, non identifica una causa o un GARCH.
- Aggregati ACF: somma dei numeratori e denominatori dei workout, sia osservati sia rimescolati. Sono conservati i rapporti per ciascuna replica aggregata in interval_null_aggregate.npz (riga 0 osservata). ARCH-LM a 5/15/30 lag senza attraversare intervalli; BH-FDR su workout×lag per modalità. ARCH su parti non normalizzate può risentire di differenze di varianza fra intervalli: il confronto con rimescolamenti e within_scaled è più informativo per distinguere il contesto.

Convenzione p Monte Carlo: [SciPy permutation_test](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.permutation_test.html).

## ACF e numerosità a 1 e 50 secondi

| split | mode | lag_s | acf | pairs | null_median | null_high |
|---|---|---|---|---|---|---|
| test | raw | 1 | 0.1568 | 51504 | 0.03093 | 0.05347 |
| test | raw | 50 | 0.01337 | 48771 | 0.009563 | 0.02512 |
| test | within | 1 | 0.1272 | 51263 | -0.002584 | 0.02074 |
| test | within | 50 | -0.008631 | 41310 | -0.00365 | 0.01457 |
| test | within_scaled | 1 | 0.1373 | 51263 | -0.002512 | 0.01804 |
| test | within_scaled | 50 | -0.001082 | 41310 | -0.001456 | 0.008905 |
| test | plateau30 | 1 | 0.1277 | 43666 | -0.01534 | 0.01959 |
| test | plateau30 | 50 | -0.003771 | 38517 | -0.002912 | 0.01672 |
| test | plateau60 | 1 | 0.1374 | 40202 | -0.004146 | 0.01591 |
| test | plateau60 | 50 | -0.004259 | 35978 | -0.003634 | 0.01548 |
| validation | raw | 1 | 0.1662 | 91365 | 0.0252 | 0.03859 |
| validation | raw | 50 | 0.01652 | 87797 | 0.01334 | 0.02455 |
| validation | within | 1 | 0.1382 | 91035 | -0.005993 | 0.006853 |
| validation | within | 50 | -0.00405 | 77554 | -0.002026 | 0.007981 |
| validation | within_scaled | 1 | 0.1584 | 91035 | -0.002384 | 0.008166 |
| validation | within_scaled | 50 | -0.0006607 | 77554 | -0.001501 | 0.004528 |
| validation | plateau30 | 1 | 0.1311 | 80793 | -0.003649 | 0.007259 |
| validation | plateau30 | 50 | -0.003325 | 73401 | -0.001829 | 0.01023 |
| validation | plateau60 | 1 | 0.1365 | 76006 | -0.003557 | 0.008484 |
| validation | plateau60 | 50 | -0.002765 | 69400 | -0.001929 | 0.009326 |

## Confronto delle finestre con il riferimento aggregato

| split | mode | window | observed | null_median | null_high | peak_lag_s | p_value | p_fdr |
|---|---|---|---|---|---|---|---|---|
| test | raw | short_1_10 | 0.06575 | 0.02676 | 0.03101 | 1 | 0.002 | 0.002 |
| test | raw | peak_40_60 | 0.03386 | 0.02419 | 0.03427 | 48 | 0.062 | 0.062 |
| test | within | short_1_10 | 0.03396 | -0.00281 | 0.0008731 | 1 | 0.002 | 0.002 |
| test | within | peak_40_60 | 0.01857 | 0.01286 | 0.02655 | 43 | 0.236 | 0.236 |
| test | within_scaled | short_1_10 | 0.03865 | -0.00166 | 0.0007018 | 1 | 0.002 | 0.002 |
| test | within_scaled | peak_40_60 | 0.009669 | 0.006659 | 0.01381 | 55 | 0.23 | 0.23 |
| test | plateau30 | short_1_10 | 0.03668 | -0.008526 | -0.003479 | 1 | 0.002 | 0.002 |
| test | plateau30 | peak_40_60 | 0.03539 | 0.01583 | 0.03407 | 43 | 0.044 | 0.044 |
| test | plateau60 | short_1_10 | 0.05003 | -0.00277 | 0.001754 | 1 | 0.002 | 0.002 |
| test | plateau60 | peak_40_60 | 0.02886 | 0.01467 | 0.03038 | 55 | 0.07 | 0.07 |
| validation | raw | short_1_10 | 0.06682 | 0.02278 | 0.02538 | 1 | 0.002 | 0.002 |
| validation | raw | peak_40_60 | 0.03373 | 0.02344 | 0.03095 | 45 | 0.016 | 0.032 |
| validation | within | short_1_10 | 0.03932 | -0.005517 | -0.00272 | 1 | 0.002 | 0.002 |
| validation | within | peak_40_60 | 0.01828 | 0.007172 | 0.01405 | 40 | 0.012 | 0.024 |
| validation | within_scaled | short_1_10 | 0.04955 | -0.002117 | -0.0002392 | 1 | 0.002 | 0.002 |
| validation | within_scaled | peak_40_60 | 0.01598 | 0.004971 | 0.01067 | 45 | 0.004 | 0.008 |
| validation | plateau30 | short_1_10 | 0.05552 | -0.003134 | 0.000204 | 1 | 0.002 | 0.002 |
| validation | plateau30 | peak_40_60 | 0.01931 | 0.008548 | 0.01583 | 45 | 0.02 | 0.04 |
| validation | plateau60 | short_1_10 | 0.0584 | -0.001893 | 0.0008124 | 1 | 0.002 | 0.002 |
| validation | plateau60 | peak_40_60 | 0.01878 | 0.009479 | 0.01641 | 45 | 0.024 | 0.048 |

## Diffusione fra workout

| split | mode | window | workouts | above_null_fdr | median_statistic |
|---|---|---|---|---|---|
| test | plateau30 | peak_40_60 | 12 | 0 | 0.06147 |
| test | plateau30 | short_1_10 | 12 | 11 | 0.05189 |
| test | plateau60 | peak_40_60 | 12 | 0 | 0.05393 |
| test | plateau60 | short_1_10 | 12 | 12 | 0.05292 |
| test | raw | peak_40_60 | 12 | 1 | 0.0639 |
| test | raw | short_1_10 | 12 | 12 | 0.06633 |
| test | within | peak_40_60 | 12 | 0 | 0.04461 |
| test | within | short_1_10 | 12 | 12 | 0.03437 |
| test | within_scaled | peak_40_60 | 12 | 0 | 0.02179 |
| test | within_scaled | short_1_10 | 12 | 12 | 0.03974 |
| validation | plateau30 | peak_40_60 | 12 | 0 | 0.03698 |
| validation | plateau30 | short_1_10 | 12 | 12 | 0.05807 |
| validation | plateau60 | peak_40_60 | 12 | 0 | 0.03692 |
| validation | plateau60 | short_1_10 | 12 | 12 | 0.06257 |
| validation | raw | peak_40_60 | 12 | 0 | 0.04708 |
| validation | raw | short_1_10 | 12 | 12 | 0.07322 |
| validation | within | peak_40_60 | 12 | 0 | 0.03839 |
| validation | within | short_1_10 | 12 | 12 | 0.047 |
| validation | within_scaled | peak_40_60 | 12 | 1 | 0.03005 |
| validation | within_scaled | short_1_10 | 12 | 12 | 0.05206 |

## ARCH-LM nei plateau e negli intervalli

| split | mode | lag_s | nobs | lm_sum | df | p_value | significant_fdr | median_r_squared |
|---|---|---|---|---|---|---|---|---|
| test | plateau30 | 5 | 43128 | 1972 | 60 | <1e-300 | 12 | 0.04336 |
| test | plateau30 | 15 | 41955 | 2238 | 180 | <1e-300 | 12 | 0.0526 |
| test | plateau30 | 30 | 40308 | 2610 | 360 | <1e-300 | 12 | 0.0597 |
| test | plateau60 | 5 | 39837 | 1568 | 60 | 2.72e-288 | 12 | 0.03696 |
| test | plateau60 | 15 | 38957 | 2099 | 180 | <1e-300 | 12 | 0.05293 |
| test | plateau60 | 30 | 37645 | 2480 | 360 | <1e-300 | 12 | 0.06278 |
| test | raw | 5 | 51268 | 2563 | 60 | <1e-300 | 12 | 0.04423 |
| test | raw | 15 | 50683 | 3355 | 180 | <1e-300 | 12 | 0.06363 |
| test | raw | 30 | 49851 | 3450 | 360 | <1e-300 | 12 | 0.07045 |
| test | within | 5 | 50063 | 2679 | 60 | <1e-300 | 12 | 0.04418 |
| test | within | 15 | 47072 | 3101 | 180 | <1e-300 | 12 | 0.05947 |
| test | within | 30 | 43757 | 3302 | 360 | <1e-300 | 12 | 0.06912 |
| test | within_scaled | 5 | 50063 | 2237 | 60 | <1e-300 | 12 | 0.04372 |
| test | within_scaled | 15 | 47072 | 2665 | 180 | <1e-300 | 12 | 0.0561 |
| test | within_scaled | 30 | 43757 | 2712 | 360 | <1e-300 | 12 | 0.06036 |
| validation | plateau30 | 5 | 80061 | 3234 | 60 | <1e-300 | 12 | 0.03676 |
| validation | plateau30 | 15 | 78463 | 4253 | 180 | <1e-300 | 12 | 0.06272 |
| validation | plateau30 | 30 | 76157 | 4816 | 360 | <1e-300 | 12 | 0.06791 |
| validation | plateau60 | 5 | 75445 | 3115 | 60 | <1e-300 | 12 | 0.04125 |
| validation | plateau60 | 15 | 74076 | 4028 | 180 | <1e-300 | 12 | 0.06098 |
| validation | plateau60 | 30 | 72051 | 4493 | 360 | <1e-300 | 12 | 0.06576 |
| validation | raw | 5 | 91065 | 3924 | 60 | <1e-300 | 12 | 0.04351 |
| validation | raw | 15 | 90325 | 4951 | 180 | <1e-300 | 12 | 0.06124 |
| validation | raw | 30 | 89237 | 5512 | 360 | <1e-300 | 12 | 0.06734 |
| validation | within | 5 | 89424 | 3870 | 60 | <1e-300 | 12 | 0.04166 |
| validation | within | 15 | 85425 | 4781 | 180 | <1e-300 | 12 | 0.06014 |
| validation | within | 30 | 80922 | 4755 | 360 | <1e-300 | 12 | 0.06638 |
| validation | within_scaled | 5 | 89424 | 3506 | 60 | <1e-300 | 12 | 0.0365 |
| validation | within_scaled | 15 | 85425 | 4000 | 180 | <1e-300 | 12 | 0.04487 |
| validation | within_scaled | 30 | 80922 | 3901 | 360 | <1e-300 | 12 | 0.0505 |

## Durata e ripetizione degli intervalli

| split | intervals | duration_median_s | duration_40_60 | recurrence_40_60 |
|---|---|---|---|---|
| test | 300 | 31 | 12 | 10 |
| validation | 408 | 32 | 9 | 20 |

Durate comprensive dei campioni iniziali senza innovazione; numero di valori finiti separato nel catalogo. Ripetizione = distanza fra inizi consecutivi con lo stesso target nello stesso segmento, inclusi eventuali cambi lap a target invariato. Non è una stima di periodicità. Le fasce 40–60 s sono confronti descrittivi; l’assenza di durate in questa fascia non esclude altri schemi temporali.

## Localizzazione del rialzo per workout

| split | workout_id | intervals | median_duration_s | duration_40_60 | recurrence_40_60 | raw_observed | raw_peak_lag_s | raw_p_fdr | within_scaled_observed | within_scaled_peak_lag_s | within_scaled_p_fdr | plateau60_observed | plateau60_peak_lag_s | plateau60_p_fdr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| test | 260819062707 | 3 | 294 | 0 | 0 | 0.02502 | 46 | 0.8136 | 0.02554 | 46 | 0.8613 | 0.02869 | 46 | 0.8291 |
| test | 260826062619 | 49 | 30 | 1 | 1 | 0.08405 | 47 | 0.549 | 0.0279 | 55 | 0.8613 | 0.06916 | 55 | 0.6293 |
| test | 260827070608 | 13 | 185 | 2 | 0 | 0.02181 | 48 | 0.7604 | 0.01848 | 48 | 0.8858 | 0.06022 | 50 | 0.6293 |
| test | 260829063044 | 15 | 241 | 4 | 0 | 0.01338 | 43 | 0.968 | 0.007868 | 60 | 0.8858 | 0.01738 | 53 | 0.8291 |
| test | 260830095410 | 7 | 196 | 0 | 0 | 0.07871 | 55 | 0.504 | 0.1391 | 55 | 0.24 | 0.09385 | 55 | 0.6293 |
| test | 260901062237 | 49 | 31 | 1 | 0 | 0.07277 | 47 | 0.4224 | 0.02167 | 59 | 0.8858 | 0.0258 | 59 | 0.8291 |
| test | 260902062649 | 12 | 256.5 | 1 | 0 | 0.009095 | 41 | 0.936 | 0.003368 | 41 | 0.978 | 0.02358 | 48 | 0.8291 |
| test | 260904062108 | 16 | 184.5 | 3 | 0 | 0.05504 | 58 | 0.7087 | 0.01662 | 48 | 0.8858 | 0.04765 | 48 | 0.7808 |
| test | 260905142842 | 11 | 95 | 0 | 0 | 0.125 | 43 | 0.4224 | 0.01304 | 52 | 0.978 | -0.002086 | 52 | 1 |
| test | 260908061657 | 63 | 30 | 0 | 2 | 0.1871 | 46 | 0.096 | 0.1613 | 56 | 0.072 | 0.1795 | 56 | 0.192 |
| test | 260915062325 | 46 | 30 | 0 | 7 | 0.1508 | 48 | 0.048 | 0.0269 | 43 | 0.8613 | 0.07034 | 43 | 0.6293 |
| test | 260919065417 | 16 | 244.5 | 0 | 0 | 0.04043 | 46 | 0.4713 | 0.0219 | 56 | 0.8613 | 0.0805 | 46 | 0.6293 |
| validation | 260606075342 | 22 | 530.5 | 1 | 0 | 0.03342 | 45 | 0.549 | 0.02731 | 40 | 0.4183 | 0.02273 | 45 | 0.7646 |
| validation | 260609170059 | 52 | 31 | 0 | 4 | 0.05555 | 49 | 0.936 | 0.02231 | 59 | 0.8613 | 0.03504 | 45 | 0.7646 |
| validation | 260616171138 | 61 | 31 | 2 | 3 | 0.07379 | 47 | 0.4 | 0.02438 | 58 | 0.8613 | 0.04499 | 58 | 0.6293 |
| validation | 260621150426 | 8 | 1067 | 0 | 0 | 0.04147 | 45 | 0.4224 | 0.0402 | 45 | 0.24 | 0.04405 | 45 | 0.6293 |
| validation | 260623171613 | 12 | 295.5 | 1 | 0 | 0.03349 | 43 | 0.4224 | 0.03513 | 43 | 0.672 | 0.02062 | 53 | 0.8291 |
| validation | 260624171412 | 48 | 31 | 1 | 1 | 0.1178 | 45 | 0.4224 | 0.05329 | 48 | 0.24 | 0.1046 | 49 | 0.7646 |
| validation | 260708172128 | 14 | 422.5 | 0 | 0 | 0.02913 | 45 | 0.7333 | 0.03131 | 45 | 0.672 | 0.02252 | 47 | 0.8291 |
| validation | 260714172507 | 14 | 360.5 | 0 | 0 | 0.05269 | 55 | 0.549 | 0.02243 | 55 | 0.8613 | 0.04382 | 44 | 0.7646 |
| validation | 260716153012 | 15 | 211 | 0 | 0 | 0.0371 | 59 | 0.549 | 0.03607 | 42 | 0.444 | 0.003836 | 42 | 1 |
| validation | 260721071628 | 63 | 31 | 2 | 8 | 0.05449 | 48 | 0.9454 | 0.07881 | 56 | 0.048 | 0.07293 | 56 | 0.7646 |
| validation | 260801060832 | 24 | 518 | 0 | 0 | 0.03953 | 57 | 0.4224 | 0.02656 | 45 | 0.24 | 0.03395 | 57 | 0.6293 |
| validation | 260811165713 | 75 | 30 | 2 | 4 | 0.07743 | 44 | 0.4224 | 0.0288 | 44 | 0.8613 | 0.03881 | 58 | 0.8291 |

## File e riproduzione

`python -B -m power_response_estimation.diagnostics_analysis --intervals`

- interval_acf.csv: tutte le ACF, coppie e bande nulle per workout/split.
- interval_permutation_windows.csv e interval_permutation_summary.csv: statistiche delle finestre e p-value.
- interval_arch.csv e interval_arch_aggregate.csv: ARCH-LM per workout e split.
- interval_catalog.csv: confini, durate, target, lap e ripetizioni.
- interval_peak_localization.csv: durata/ripetizione e massimo 40–60 s per ogni workout.
- interval_contributions.csv: supporto e contributo di ogni workout al lag 50.
- interval_manifest.json: configurazione, seed, hash sorgenti/codice e artefatti congelati.

![Confronti aggregati](interval_acf_summary.png)

![Confronti per workout](interval_acf_workouts.png)
